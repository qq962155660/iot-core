package iot.vertx.broker;

import java.util.HashMap;
import java.util.Map;

import io.vertx.core.AbstractVerticle;
import io.vertx.core.json.JsonObject;
import io.vertx.kafka.client.producer.KafkaProducer;
import io.vertx.kafka.client.producer.KafkaProducerRecord;

public class MqttCoreLayer extends AbstractVerticle {

	private KafkaProducer<String, String> producer;

	@Override
	public void start() {
		Map<String, String> config = new HashMap<>();
		config.put("bootstrap.servers", "192.168.29.35:9092,192.168.29.35:9092,192.168.29.36:9092");
		config.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
		config.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer");

        producer = KafkaProducer.create(vertx, config);
		
		vertx.eventBus().consumer("e-mqtt-message", message -> {
			JsonObject payload = (JsonObject) message.body();

//			System.out.println("Processing biz msg: " + payload.toString());

			publishToKafka("Mqtt-cdf", payload);

		});
		System.out.println("Module mqtt-core start success");
	}

	private void publishToKafka(String topic,JsonObject  message) {
		KafkaProducerRecord<String, String> record = KafkaProducerRecord.create(topic, message.toString());

		producer.write(record, ar -> {
			if (!ar.succeeded())
				System.err.println("Failed to send message to Kafka: " + ar.cause().getMessage());
		});
	}

	@Override
	public void stop() {
		producer.close(ar -> {
			if (!ar.succeeded()) 
				System.err.println("Failed to close Kafka producer: " + ar.cause().getMessage());
			
		});
	}
}

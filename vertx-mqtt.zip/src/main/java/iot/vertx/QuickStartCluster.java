package iot.vertx;

import io.vertx.core.Vertx;
import io.vertx.core.VertxOptions;
import iot.vertx.broker.MqttConnLayer;
import iot.vertx.broker.MqttCoreLayer;

/**
 * java -jar QuickClusterStart $1
 * 
 * 所有layer模块都可以独立部署
 * 
 * @author peak.chen
 *
 */
public class QuickStartCluster {

	public static void main(String[] args) {
		if(args.length !=1){
			return;
		}
		if(!args[0].equals("mqtt-conn")&&!args[0].equals("mqtt-core")){
			System.err.print("Unsupport args");
			return;
		}
		
		VertxOptions options = new VertxOptions();
		if(args[0].equals("mqtt-conn")){
			Vertx.clusteredVertx(options, res -> {
	            if (res.succeeded()) {
	                res.result().deployVerticle(new MqttConnLayer("0.0.0.0",1883));
	            }
	        });
		}else if(args[0].equals("mqtt-core")){
			Vertx.clusteredVertx(options, res -> {
	            if (res.succeeded()) {
	                res.result().deployVerticle(new MqttCoreLayer());
	            }
	        });
			
		}
	}

}

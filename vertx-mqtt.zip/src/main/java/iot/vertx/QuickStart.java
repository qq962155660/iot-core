package iot.vertx;

import io.vertx.core.Vertx;
import iot.vertx.broker.MqttConnLayer;
import iot.vertx.broker.MqttCoreLayer;

public class QuickStart {

	public static void main(String[] args) throws InterruptedException {
		Vertx vertx = Vertx.vertx();
		vertx.deployVerticle(new MqttConnLayer("0.0.0.0",1883));
		vertx.deployVerticle(new MqttCoreLayer());
	}

}

package iot.vertx.common;

public class Test {

}
